import flowerImage from "../img/pexels-photo-673857.jpeg";
import pineappleImage from "../img/pexels-karolina-grabowska-4195527.jpg";
import colaImage from "../img/pexels-olena-bohovyk-3819969.jpg";
import skyImage from "../img/pexels-soubhagya-maharana-5245865.jpg";
let products = [
    {
      id: 1,
      name: "Placeholder"
    },
    { 
      id: 2,
      name: "Bloemen",
      img: flowerImage
    },
    {
      id: 3,
      name: "Annanas",
      img: pineappleImage
    },
    {
        id: 4,
        name: "Bloemen",
        img: flowerImage
      }
  ];

  export default {products};