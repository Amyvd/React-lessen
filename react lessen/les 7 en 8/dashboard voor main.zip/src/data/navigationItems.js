let navigationItems = 
    [
        {
            name: "Home",
            message: 0,
        },
        {
            name: "Facturen",
            message: 3,
        },
        {
            name: "Bestellingen",
            message: 0,
        },
        {
            name: "Contact",
            message: 2,
        },
        {
            name: "Retour",
            message: 1,
        }
    ];
export default {navigationItems};