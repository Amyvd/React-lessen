import Dashboard from '../components/Dashboard/Dashboard';
import './App.css';

function App() {
  return (
    <Dashboard/>
  );
}

export default App;
